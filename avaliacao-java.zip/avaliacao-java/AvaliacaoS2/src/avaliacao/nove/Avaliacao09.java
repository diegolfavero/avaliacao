package avaliacao.nove;

/* 
 * Avaliacao - Binary Tree
 * (No 7) [1] - (No 6) [2] - (No 5) [3] - (No 4) [4]
 * (No 3) [5] - (No 2) [6]
 * (No 1)[7]
 */

public class Avaliacao09 {
	
	public static void main(String[] args) {
		
		BinaryTree no7 = new BinaryTree(1);
		BinaryTree no6 = new BinaryTree(2);
		BinaryTree no5 = new BinaryTree(3);
		BinaryTree no4 = new BinaryTree(4);
		
		BinaryTree no3 = new BinaryTree(5, no7, no6);
		BinaryTree no2 = new BinaryTree(6, no5, no4);
		
		BinaryTree no1 = new BinaryTree(7, no3, no2);
		
		System.out.println(no1.somaNo());
		
		System.out.println(no7.somaNos(no1));
		
	}

}
