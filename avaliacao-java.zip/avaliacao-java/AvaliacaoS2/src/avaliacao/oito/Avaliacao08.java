package avaliacao.oito;

/*
 * A = 10256
 * B = 512
 * C = 15012256
*/

public class Avaliacao08 {

	public static void main(String[] args) {
		
		System.out.println(CriarInteiroC.criarAB(10256, 512));
	
		System.out.println(CriarInteiroC.criarAB(1025, 51));
	
	}

}
