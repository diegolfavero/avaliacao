package avaliacao.oito;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Avaliacao 08

public class CriarInteiroC {

	private static final String STRING_VAZIO = "";

	private static final int C_MAIOR_MILHAO = -1;

	public static final int LIMITE_MILHAO = 1000000;

	public static Integer criarAB(Integer a, Integer b) {
		
		String stringA = a.toString();
		String stringB = b.toString();
		
		if (Integer.valueOf(stringA + stringB) > LIMITE_MILHAO) {
			
			return C_MAIOR_MILHAO;
		
		} else {
		
			return Integer.valueOf(criarNumero(stringA, stringB));
		
		}
	
	}

	private static String criarNumero(String strA, String strB) {

		Map<Integer, String> mapA = insereStringMap(strA);
		Map<Integer, String> mapB = insereStringMap(strB);

		Integer i = 0;

		StringBuilder sb = new StringBuilder();

		do {

			sb.append(verificaValor(mapA.get(i)) ? mapA.get(i) : STRING_VAZIO)
				.append(verificaValor(mapB.get(i)) ? mapB.get(i) : STRING_VAZIO);

			i++;

		} while (verificaValor(mapA.get(i)) || verificaValor(mapB.get(i)));

		return sb.toString();

	}

	private static boolean verificaValor(String valor) {
		
		return valor != null && !STRING_VAZIO.equals(valor);
	
	}

	private static Map<Integer, String> insereStringMap(String valor) {

		Map<Integer, String> map = new HashMap<Integer, String>();

		List<String> listaString = Arrays.asList(valor.split(STRING_VAZIO));

		for (int i = 0; i < listaString.size(); i++) {
			map.put(i, listaString.get(i));
		}

		return map;
	}

}
