package avaliacao.nove;

// Avaliacao 09

public class BinaryTree {

	private int valor;

	private BinaryTree left;

	private BinaryTree right;

	public BinaryTree() {
		this(0);
	}

	public BinaryTree(int valor) {
		this(valor, null, null);
	}

	public BinaryTree(int valor, BinaryTree left, BinaryTree right) {
		setValor(valor);
		setLeft(left);
		setRight(right);
	}

	private int somarTodosNos() {
		int soma = getValor();
		if (getLeft() != null) {
			soma += getLeft().somaNo();
		}
		if (getRight() != null) {
			soma += getRight().somaNo();
		}
		return soma;
	}
	
	public int somaNos(BinaryTree binaryTree) {
		return binaryTree != null ? binaryTree.somarTodosNos() : somarTodosNos();
	}
	
	public int somaNo() {
		return somaNos(null);
	}
	
	public int getValor() {
		return valor;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}

	public BinaryTree getLeft() {
		return left;
	}

	public void setLeft(BinaryTree left) {
		this.left = left;
	}

	public BinaryTree getRight() {
		return right;
	}

	public void setRight(BinaryTree right) {
		this.right = right;
	}

}
